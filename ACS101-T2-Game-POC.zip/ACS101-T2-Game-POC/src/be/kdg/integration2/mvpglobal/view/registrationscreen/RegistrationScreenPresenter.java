package be.kdg.integration2.mvpglobal.view.registrationscreen;

import be.kdg.integration2.mvpglobal.model.MVPModel;
import be.kdg.integration2.mvpglobal.view.signinscreen.SigninScreenPresenter;
import be.kdg.integration2.mvpglobal.view.signinscreen.SigninScreenView;
import be.kdg.integration2.mvpglobal.view.signupscreen.SignupScreenPresenter;
import be.kdg.integration2.mvpglobal.view.signupscreen.SignupScreenView;
import javafx.stage.Screen;

public class RegistrationScreenPresenter {
    private MVPModel model;
    private RegistrationScreenView view;

    public RegistrationScreenPresenter(MVPModel model, RegistrationScreenView view) {
        this.model = model;
        this.view = view;
        windowsHandler();
    }

    public void windowsHandler() {
        view.getExitButton().setOnAction(e -> System.exit(0));

        view.getRegisterButton().setOnAction(e -> {
            SignupScreenView signupView = new SignupScreenView();
            view.getScene().setRoot(signupView);
            signupView.getScene().getWindow().setHeight(325);
            signupView.getScene().getWindow().setWidth(550);
            signupView.getScene().getWindow().setX((Screen.getPrimary().getBounds().getWidth() / 2) - 250);
            signupView.getScene().getWindow().setY((Screen.getPrimary().getBounds().getHeight() / 2) - 250);
            SignupScreenPresenter signupPresenter = new SignupScreenPresenter(model, signupView);
        });

        view.getLoginButton().setOnAction(e -> {
            SigninScreenView signinView = new SigninScreenView();
            view.getScene().setRoot(signinView);
            signinView.getScene().getWindow().setHeight(250);
            signinView.getScene().getWindow().setWidth(550);
            signinView.getScene().getWindow().setX((Screen.getPrimary().getBounds().getWidth() / 2) - 250);
            signinView.getScene().getWindow().setY((Screen.getPrimary().getBounds().getHeight() / 2) - 250);
            SigninScreenPresenter signupPresenter = new SigninScreenPresenter(model, signinView);
        });
    }
}
