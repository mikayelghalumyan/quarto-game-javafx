package be.kdg.integration2.mvpglobal.view.signinscreen;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;

public class SigninScreenView extends StackPane {
    private ImageView backgroundView;
    private Label username;
    private Label password;
    private TextField usernameInput;
    private PasswordField passwordInput;
    private Button submitButton;

    public SigninScreenView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        Image backgroundImage = new Image(getClass().getResource("/images/start_background.png").toExternalForm());
        backgroundView = new ImageView(backgroundImage);
        username = new Label("Username: ");
        password = new Label("Password: ");
        usernameInput = new TextField();
        passwordInput = new PasswordField();
        submitButton = new Button("Submit");
    }

    private void layoutNodes() {
        GridPane grid = new GridPane();

        setPadding(new Insets(0, 20, 0, 20));
        grid.setHgap(20);
        grid.setVgap(15);

        grid.setConstraints(this.username, 0, 0, 1, 1, HPos.LEFT, VPos.CENTER, Priority.NEVER, Priority.NEVER);
        grid.add(this.username, 0, 0);

        grid.setConstraints(this.usernameInput, 1, 0, 1, 1, HPos.LEFT, VPos.CENTER, Priority.ALWAYS, Priority.NEVER);
        grid.add(this.usernameInput, 1, 0);

        grid.setConstraints(this.password, 0, 1, 1, 1, HPos.LEFT, VPos.CENTER, Priority.NEVER, Priority.NEVER);
        grid.add(this.password, 0, 1);

        grid.setConstraints(this.passwordInput, 1, 1, 1, 1, HPos.LEFT, VPos.CENTER, Priority.NEVER, Priority.NEVER);
        grid.add(this.passwordInput, 1, 1);

        grid.setConstraints(this.submitButton, 0, 4, 2, 1, HPos.RIGHT, VPos.CENTER, Priority.NEVER, Priority.NEVER);
        grid.add(this.submitButton, 0, 4);

        StackPane backgroundPane = new StackPane(backgroundView);
        getChildren().addAll(backgroundPane, grid);

        grid.setAlignment(Pos.CENTER);

        getStylesheets().add(getClass().getResource("/stylesheets/registration.css").toExternalForm());
    }

    public TextField getUsernameInput() {
        return usernameInput;
    }

    public PasswordField getPasswordInput() {
        return passwordInput;
    }

    public Button getSubmitButton() {
        return submitButton;
    }
}
