package be.kdg.integration2.mvpglobal.view.boardscreen;

import be.kdg.integration2.mvpglobal.model.Cell;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.*;
import javafx.stage.Screen;

import java.util.HashMap;
import java.util.Map;

public class BoardScreenView extends BorderPane {
    private static final double CELL_SIZE = 125;

    private GridPane boardGrid;
    private Button[][] boardButtons;
    private Label instructionLabel;
    private FlowPane piecesPane;
    private Label selectionLabel;
    private VBox selectionContainer;
    private FlowPane selectionPane;

    private final Map<String, Image> imageCache = new HashMap<>();

    public BoardScreenView() {
        initializeNodes();
        layoutNodes();
    }

    public void initializeNodes() {
        boardGrid = new GridPane();
        boardButtons = new Button[4][4];
        instructionLabel = new Label();
        piecesPane = new FlowPane();
        selectionLabel = new Label();
        selectionContainer = new VBox();
        selectionPane = new FlowPane();
    }

    public void layoutNodes() {
        instructionLabel.setStyle(
                "-fx-font-family: \"Comic Sans MS\"; -fx-text-fill: #231e1e; -fx-font-size:34px; -fx-font-weight:bold;"
        );
        instructionLabel.setAlignment(Pos.CENTER);
        instructionLabel.setPadding(new Insets(60, 0, 0, 0));
        BorderPane.setAlignment(instructionLabel, Pos.CENTER);
        createBoardGrid();
        createSelectionPane();
        createAvailablePiecesPane();

        double gapWidth = Screen.getPrimary().getBounds().getWidth() * 0.05;

        HBox center = new HBox(gapWidth, selectionContainer, boardGrid, piecesPane);
        center.setAlignment(Pos.CENTER);
        center.setPadding(new Insets(10));

        setTop(instructionLabel);
        setCenter(center);

        Image backgroundImage = new Image(getClass().getResource("/images/start_background.png").toExternalForm());
        BackgroundImage background = new BackgroundImage(
                backgroundImage,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT,
                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true)
        );
        setBackground(new Background(background));
    }

    private void createBoardGrid() {
        boardGrid.setHgap(5);
        boardGrid.setVgap(5);
        boardGrid.setAlignment(Pos.CENTER);

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                Button cell = new Button();
                cell.setPrefSize(CELL_SIZE, CELL_SIZE);
                cell.setMaxSize(CELL_SIZE, CELL_SIZE);
                cell.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                cell.setStyle("-fx-background-radius: 15px; -fx-background-radius: 15px; -fx-border-width: 5px; " +
                        "-fx-border-color: #4B3B30; -fx-background-color: #A67B5B");

                boardButtons[i][j] = cell;
                boardGrid.add(cell, j, i);
            }
        }
    }

    private void createSelectionPane() {
        selectionLabel = new Label("This is your piece");
        selectionLabel.setStyle("-fx-font-family: \"Comic Sans MS\"; -fx-text-fill: #231e1e; -fx-font-size:20px; -fx-font-weight:bold;");
        selectionLabel.setAlignment(Pos.CENTER);

        selectionPane = new FlowPane(8, 8);
        selectionPane.setPrefWrapLength(CELL_SIZE + 50);
        selectionPane.setPrefSize(CELL_SIZE + 25, CELL_SIZE + 25);
        selectionPane.setStyle("-fx-background-radius:20px; -fx-background-color: #C19A6B; -fx-border-radius: 20px; -fx-border-color: #4B3B30; -fx-border-width: 5px; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 5, 0, 3, 3);");
        selectionPane.setAlignment(Pos.CENTER);

        selectionContainer = new VBox(5, selectionLabel, selectionPane);
        selectionContainer.setAlignment(Pos.CENTER);
    }

    private void createAvailablePiecesPane() {
        piecesPane = new FlowPane(4, 4);
        piecesPane.setPrefWrapLength(400);
        piecesPane.setMaxHeight(400);
        piecesPane.setAlignment(Pos.CENTER);
        piecesPane.setStyle("-fx-background-radius:20px; -fx-background-color: #C19A6B; -fx-border-radius: 20px; -fx-border-color: #4B3B30; -fx-border-width: 5px;" +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 5, 0, 3, 3);");
    }
    public void showGivenPiece(String pieceId) {
        selectionLabel.setText("This is your piece");
        selectionPane.getChildren().clear();
        Node n = createDraggableOrPlaceholder(pieceId);
        n.setUserData(pieceId);
        selectionPane.getChildren().add(n);
    }

    public Node createDraggableOrPlaceholder(String pid) {
        Image img = imageCache.get(pid);
        if (img != null) {
            ImageView iv = new ImageView(img);
            iv.setFitWidth(CELL_SIZE - 40);
            iv.setFitHeight(CELL_SIZE - 40);
            iv.setPreserveRatio(true);
            iv.setOnDragDetected(e -> {
                Dragboard db = iv.startDragAndDrop(TransferMode.COPY);
                ClipboardContent cc = new ClipboardContent();
                cc.putString(pid);
                db.setContent(cc);
                e.consume();
            });
            return iv;
        } else {
            Label lbl = new Label(pid.replace("-", "\n"));
            lbl.setPrefSize(CELL_SIZE, CELL_SIZE);
            lbl.setStyle("-fx-font-family: \"Comic Sans MS\"; -fx-text-fill: #231e1e; -fx-border-color:black; -fx-font-size:10px; -fx-alignment:center;");
            lbl.setOnDragDetected(e -> {
                Dragboard db = lbl.startDragAndDrop(TransferMode.COPY);
                ClipboardContent cc = new ClipboardContent();
                cc.putString(pid);
                db.setContent(cc);
                e.consume();
            });
            return lbl;
        }
    }
    public void promptPlaceGiven() {
        instructionLabel.setText("Place the piece which was given to you");
    }
    public void updateBoard(Cell[][] board) {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                Button cell = boardButtons[i][j];
                cell.setGraphic(null);
                cell.setText(null);
                String pid = board[i][j].getValueId();
                if (pid != null) {
                    Image img = imageCache.get(pid);
                    if (img != null) {
                        ImageView iv = new ImageView(img);
                        iv.setFitWidth(CELL_SIZE - 40);
                        iv.setFitHeight(CELL_SIZE - 40);
                        iv.setPreserveRatio(true);
                        cell.setGraphic(iv);
                        cell.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                    } else {
                        cell.setText(pid.replace("-", "\n"));
                        cell.setContentDisplay(ContentDisplay.TEXT_ONLY);
                    }
                }
            }
        }
    }

    GridPane getBoardGrid() {
        return boardGrid;
    }

    void setBoardGrid(GridPane boardGrid) {
        this.boardGrid = boardGrid;
    }

    Button[][] getBoardButtons() {
        return boardButtons;
    }

    void setBoardButtons(Button[][] boardButtons) {
        this.boardButtons = boardButtons;
    }

    Label getInstructionLabel() {
        return instructionLabel;
    }

    void setInstructionLabel(Label instructionLabel) {
        this.instructionLabel = instructionLabel;
    }

    FlowPane getPiecesPane() {
        return piecesPane;
    }

    void setPiecesPane(FlowPane piecesPane) {
        this.piecesPane = piecesPane;
    }

    Label getSelectionLabel() {
        return selectionLabel;
    }

    void setSelectionLabel(Label selectionLabel) {
        this.selectionLabel = selectionLabel;
    }

    VBox getSelectionContainer() {
        return selectionContainer;
    }

    void setSelectionContainer(VBox selectionContainer) {
        this.selectionContainer = selectionContainer;
    }

    FlowPane getSelectionPane() {
        return selectionPane;
    }

    void setSelectionPane(FlowPane selectionPane) {
        this.selectionPane = selectionPane;
    }

    Map<String, Image> getImageCache() {
        return imageCache;
    }
}
