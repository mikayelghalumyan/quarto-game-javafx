package be.kdg.integration2.mvpglobal.view.helpscreen;

import be.kdg.integration2.mvpglobal.model.MVPModel;
import javafx.event.Event;

public class HelpScreenPresenter {
    private MVPModel model;
    private HelpScreenView view;

    public HelpScreenPresenter(MVPModel model, HelpScreenView view) {
        this.model = model;
        this.view = view;
        EventHandlers();
    }

    private void EventHandlers() {
        view.getOkButton().setOnMouseClicked(event -> handleCloseEvent(event));
    }

    private void handleCloseEvent(Event event) {
        view.getScene().getWindow().hide();
    }
}
