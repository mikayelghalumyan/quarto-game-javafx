package be.kdg.integration2.mvpglobal.view.mainscreen;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Screen;

import java.util.List;

public class MainScreenView extends StackPane  {
    private ImageView backgroundView;
    private Button newGameButton;
    private Button continueGameButton;
    private Button leaderboardButton;
    private Button helpButton;
    private Button quitButton;
    private VBox vBox;

    private final int width = 300;
    private final int height = 75;

    public MainScreenView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        Image backgroundImage = new Image(getClass().getResource("/images/main_background.png").toExternalForm());
        backgroundView = new ImageView(backgroundImage);
        backgroundView.setPreserveRatio(false);
        backgroundView.setFitWidth(Screen.getPrimary().getBounds().getWidth() / 1.25);
        backgroundView.setFitHeight(Screen.getPrimary().getBounds().getHeight() - 200);

        newGameButton = new Button("New Game");
        continueGameButton = new Button("Continue Game");
        leaderboardButton = new Button("Leaderboard");
        helpButton = new Button("Help");
        quitButton = new Button("Quit");
        vBox = new VBox(newGameButton, continueGameButton, leaderboardButton, helpButton, quitButton);
    }

    private void layoutNodes() {
        StackPane backgroundPane = new StackPane(backgroundView);
        getChildren().addAll(backgroundPane, vBox);

        vBox.setSpacing(35);
        vBox.setAlignment(Pos.CENTER);

        List<Button> buttons = List.of(newGameButton, continueGameButton, leaderboardButton, helpButton, quitButton);

        for (Button button : buttons) {
            button.setMinWidth(width);
            button.setMaxWidth(width);
            button.setMaxHeight(height);
            button.setMinHeight(height);
        }

        getStylesheets().add(getClass().getResource("/stylesheets/buttons.css").toExternalForm());
    }

    public ImageView getBackgroundView() {
        return backgroundView;
    }

    public Button getNewGameButton() {
        return newGameButton;
    }

    public Button getContinueGameButton() {
        return continueGameButton;
    }

    public Button getLeaderboardButton() {
        return leaderboardButton;
    }

    public Button getHelpButton() {
        return helpButton;
    }

    public Button getQuitButton() {
        return quitButton;
    }
}
