package be.kdg.integration2.mvpglobal.view.registrationscreen;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.layout.StackPane;

import java.util.List;

public class RegistrationScreenView extends StackPane {
    private ImageView backgroundView;
    private Button registerButton;
    private Button loginButton;
    private Button exitButton;
    private VBox vBox;

    private final int width = 300;
    private final int height = 75;

    public RegistrationScreenView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        Image backgroundImage = new Image(getClass().getResource("/images/start_background.png").toExternalForm());
        backgroundView = new ImageView(backgroundImage);
        registerButton = new Button("Sign Up");
        loginButton = new Button("Sign In");
        exitButton = new Button("Exit");
        vBox = new VBox(registerButton, loginButton, exitButton);
    }

    private void layoutNodes() {
        StackPane backgroundPane = new StackPane(backgroundView);
        getChildren().addAll(backgroundPane, vBox);

        vBox.setSpacing(50);
        vBox.setAlignment(Pos.CENTER);

        List<Button> buttons = List.of(registerButton, loginButton, exitButton);

        for (Button button : buttons) {
            button.setMinWidth(width);
            button.setMaxWidth(width);
            button.setMaxHeight(height);
            button.setMinHeight(height);
        }

        getStylesheets().add(getClass().getResource("/stylesheets/buttons.css").toExternalForm());
    }

    public Button getRegisterButton() {
        return registerButton;
    }

    public Button getLoginButton() {
        return loginButton;
    }

    public Button getExitButton() {
        return exitButton;
    }
}
