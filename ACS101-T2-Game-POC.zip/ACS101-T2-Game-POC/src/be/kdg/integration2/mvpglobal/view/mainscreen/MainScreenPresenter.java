package be.kdg.integration2.mvpglobal.view.mainscreen;

import be.kdg.integration2.mvpglobal.model.*;

import be.kdg.integration2.mvpglobal.view.boardscreen.BoardScreenPresenter;
import be.kdg.integration2.mvpglobal.view.boardscreen.BoardScreenView;
import be.kdg.integration2.mvpglobal.view.helpscreen.HelpScreenPresenter;
import be.kdg.integration2.mvpglobal.view.helpscreen.HelpScreenView;
import be.kdg.integration2.mvpglobal.view.leaderboardscreen.LeaderBoardPresenter;
import be.kdg.integration2.mvpglobal.view.leaderboardscreen.LeaderBoardView;
import javafx.event.*;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.time.LocalDateTime;

public class MainScreenPresenter {
    private MVPModel model;
    private MainScreenView view;
    private double lastWidth;
    private double lastHeight;

    public MainScreenPresenter(MVPModel model, MainScreenView view) {
        this.model = model;
        this.view = view;
        EventHandlers();
        resizeImage();
    }

    private void EventHandlers() {
        view.getScene().getWindow().setOnCloseRequest(event -> handleCloseEvent(event));
        view.getQuitButton().setOnAction(e -> System.exit(0));
        view.getHelpButton().setOnAction(e -> {
            HelpScreenView helpScreenView = new HelpScreenView();
            HelpScreenPresenter helpScreenPresenter = new HelpScreenPresenter(model, helpScreenView);
            Stage helpScreenStage = new Stage();
            Scene helpScreenScene = new Scene(helpScreenView);
            helpScreenStage.setTitle("Rules");
            helpScreenStage.getIcons().add(new Image("/images/logo.png"));
            helpScreenStage.setScene(helpScreenScene);
            helpScreenStage.setHeight(Screen.getPrimary().getBounds().getHeight() - 200);
            helpScreenStage.show();
        });

        view.getLeaderboardButton().setOnAction(e -> {
            LeaderBoardView leaderboardView = new LeaderBoardView();
            view.getScene().setRoot(leaderboardView);
            leaderboardView.getScene().getWindow().setHeight(Screen.getPrimary().getBounds().getHeight() / 2);
            leaderboardView.getScene().getWindow().setWidth(Screen.getPrimary().getBounds().getWidth() / 2);
            leaderboardView.getScene().getWindow().setX(Screen.getPrimary().getBounds().getWidth() / 2 - 475);
            leaderboardView.getScene().getWindow().setY(Screen.getPrimary().getBounds().getHeight() / 2 - 300);
            LeaderBoardPresenter leaderboardPresenter = new LeaderBoardPresenter(model, leaderboardView);
        });

        view.getNewGameButton().setOnAction(e -> {
            model.startGameSession();
            model.getGameSession().setGameID(model.getDb().getLastGameId());
            model.getGameSession().getMove().setStartMove(LocalDateTime.now());
            BoardScreenView boardView = new BoardScreenView();
            BoardScreenPresenter boardPresenter = new BoardScreenPresenter(model, boardView);

            boardView.updateBoard(model.getCells());
            boardPresenter.updateAvailablePieces(model.getAvailablePieceIds());
            view.getScene().getWindow().hide();

            Scene scene = new Scene(boardView, view.getScene().getWidth(), view.getScene().getHeight());
            Stage boardScreenStage = new Stage();
            boardScreenStage.setTitle("Quarto");
            boardScreenStage.getIcons().add(new Image("/images/logo.png"));
            boardScreenStage.setResizable(false);
            boardScreenStage.setScene(scene);
            boardScreenStage.show();
        });

    }

    private void resizeImage() {
        view.widthProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal.doubleValue() > lastWidth) {
                view.getBackgroundView().setFitWidth(newVal.doubleValue());
                lastWidth = newVal.doubleValue();
            }
        });
        view.heightProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal.doubleValue() > lastHeight) {
                view.getBackgroundView().setFitHeight(newVal.doubleValue());
                lastHeight = newVal.doubleValue();
            }
        });
    }

    private void handleCloseEvent(Event event) {
        final Alert stopWindow = new Alert(Alert.AlertType.CONFIRMATION);
        stopWindow.setHeaderText("You're closing the application.");
        stopWindow.setContentText("Are you sure? Unsaved data may be lost.");
        stopWindow.setTitle("WARNING!");
        stopWindow.getButtonTypes().clear();
        ButtonType noButton = new ButtonType("No");
        ButtonType yesButton = new ButtonType("Yes");
        stopWindow.getButtonTypes().addAll(yesButton, noButton);
        stopWindow.showAndWait();
        if (stopWindow.getResult() == null || stopWindow.getResult().equals(noButton)) {
            event.consume();
        } else {
            view.getScene().getWindow().hide();
        }
    }
}
