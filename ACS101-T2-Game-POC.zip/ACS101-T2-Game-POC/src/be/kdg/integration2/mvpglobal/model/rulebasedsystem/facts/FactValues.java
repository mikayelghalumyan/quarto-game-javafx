package be.kdg.integration2.mvpglobal.model.rulebasedsystem.facts;

public enum FactValues {
    ENDMOVEPLAYER, ENDMOVEAI, WINNINGPOSITIONPLAYER, WINNINGPOSITIONAI, OTHERFACT;
}

