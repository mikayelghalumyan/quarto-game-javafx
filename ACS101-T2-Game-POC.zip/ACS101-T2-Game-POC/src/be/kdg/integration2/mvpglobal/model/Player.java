package be.kdg.integration2.mvpglobal.model;

/**
 * Base class representing a player in the Quarto-like game.
 * <p>
 * Serves as a common superclass for human and computer players,
 * and may hold shared behavior or properties in future expansions.
 * </p>
 *
 * <p>Currently provides a default constructor only.</p>
 *
 * @author ACS101 - TEAM 2
 * @version 1.0
 */
public class Player {

    /**
     * Default constructor for a player.
     * <p>
     * Initializes a new player instance. Subclasses may extend
     * this constructor to add additional initialization logic.
     * </p>
     */
    public Player() {
    }
}
