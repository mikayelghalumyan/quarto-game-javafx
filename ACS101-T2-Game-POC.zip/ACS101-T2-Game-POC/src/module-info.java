open module Appname {
    requires javafx.controls;
    requires javafx.media;
    requires javafx.graphics;
    requires javafx.base;
    requires java.desktop;
    requires java.sql;
}